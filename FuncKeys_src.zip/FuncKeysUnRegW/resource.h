//{{NO_DEPENDENCIES}}
// Microsoft eMbedded Visual C++ generated include file.
// Used by FUNCKEYSUNREG.RC
//
#define IDS_APP_TITLE					1
#define IDS_HELLO						2
#define IDC_FUNCKEYSUNREG				3
#define IDI_FUNCKEYSUNREG				101
#define IDM_MENU						102
#define IDD_ABOUTBOX					103
#define IDM_FILE_EXIT					40002
#define IDM_HELP_ABOUT					40003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40004
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
