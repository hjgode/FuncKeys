//registry.h

//global

int readReg(BYTE *b, ULONG *iCount){
	HKEY hKey;
	//open reg
	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"SOFTWARE\\Intermec\\FuncKeys", 0, 0, &hKey)!=ERROR_SUCCESS){
		b=NULL;
		*iCount = 0;
		return -1;
	}

	//query size of byte data 
	ULONG type = REG_BINARY;
	BYTE *buf = NULL;
	ULONG cnt = 0;
	if (RegQueryValueEx(hKey, L"KeyList", 0, &type, buf, &cnt)!=ERROR_SUCCESS){
		b=NULL;
		*iCount = 0;
		RegCloseKey(hKey);
		return -2;
	}
	//read data bytes
	buf = (BYTE*) malloc(cnt);
	if (RegQueryValueEx(hKey, L"KeyList", 0, &type, buf, &cnt)!=ERROR_SUCCESS){
		b=NULL;
		*iCount = 0;
		RegCloseKey(hKey);
		return -3;
	}
	memcpy(b, buf, cnt);
	//memcpy(iCount, cnt, sizeof(int));
	*iCount=cnt;
	RegCloseKey(hKey);
	return 0;
}

int writeReg(BYTE *b, int iCount){
	DEBUGMSG(1, (L"### entering writeReg\n"));
	HKEY hKey;
	//open reg
	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"SOFTWARE\\Intermec\\FuncKeys", 0, 0, &hKey)!=ERROR_SUCCESS){
		DEBUGMSG(1, (L" writeReg: error 0x%0x in RegOpenKeyEx\n", GetLastError()));
		//create key if not exists
		DWORD dwDisposition;
		if(RegCreateKeyEx(HKEY_LOCAL_MACHINE, L"SOFTWARE\\Intermec\\FuncKeys", 
			0, NULL, REG_OPTION_NON_VOLATILE, 0, NULL, &hKey, &dwDisposition) != ERROR_SUCCESS){
			b=NULL;
			iCount = 0;
			return -1;
		}
	}
	ULONG type = REG_BINARY;
	if(iCount==0){
		DEBUGMSG(1, (L" writeReg: iCount is 0\n"));
		if(RegSetValueEx(hKey, L"KeyList", 0, type, NULL, 0)!=ERROR_SUCCESS){
			DEBUGMSG(1, (L" writeReg: error 0x%0x in RegSetValueEx\n", GetLastError()));
			RegCloseKey(hKey);
			return -2;
		}
	}else{
		if(RegSetValueEx(hKey, L"KeyList", 0, type, b, iCount)!=ERROR_SUCCESS){
			DEBUGMSG(1, (L" writeReg: error 0x%0x in RegSetValueEx\n", GetLastError()));
			RegCloseKey(hKey);
			return -2;
		}
	}
	RegCloseKey(hKey);
	DEBUGMSG(1, (L"### leaving writeReg with no error\n"));
	return 0;
}