//{{NO_DEPENDENCIES}}
// Microsoft eMbedded Visual C++ generated include file.
// Used by FuncKeys.rc
//
#define IDD_FUNCKEYS_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDC_CHECK1                      1112
#define IDC_CHECK2                      1113
#define IDC_CHECK3                      1114
#define IDC_CHECK4                      1115
#define IDC_CHECK5                      1116
#define IDC_CHECK6                      1117
#define IDC_CHECK7                      1118
#define IDC_CHECK8                      1119
#define IDC_CHECK9                      1120
#define IDC_CHECK10                     1121
#define IDC_BTNSAVE                     1200
#define IDC_BTNTEST                     1201
#define IDC_BTNCLOSE                    1202
#define IDC_BTNAPPLY                    1203
#define IDC_BTNHELP                     1204

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1203
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
